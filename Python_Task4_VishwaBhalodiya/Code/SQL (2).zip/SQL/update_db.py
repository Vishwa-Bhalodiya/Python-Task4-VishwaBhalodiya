import mysql.connector
from mysql.connector import Error



DB_CONFIG = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': '1piece@1374',
    'database': 'testdb',  
    'port': 3306,
    'use_pure': True
}

def create_connection():
    """Establish connection to MySQL."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            return conn
    except Error as e:
        print(f"Connection failed: {e}")
    return None

def update_product_price(product_id: int, new_price: float):
  
    connection = create_connection()
    if not connection:
        return

    try:
        with connection.cursor() as cursor:
           
            cursor.execute("SELECT price FROM products WHERE id = %s", (product_id,))
            result = cursor.fetchone()
            if not result:
                print(f"No product found with ID {product_id}")
                return

            old_price = result[0]

        
            if old_price == new_price:
                print(f"Product ID {product_id} already has price {new_price}")
                return

      
            cursor.execute("UPDATE products SET price = %s WHERE id = %s", (new_price, product_id))
            connection.commit()
            print(f"Product ID {product_id} updated from {old_price} to {new_price}")

    except Error as e:
        print(f"Error updating record: {e}")
    finally:
        if connection.is_connected():
            connection.close()

def show_all_products():
   
    connection = create_connection()
    if not connection:
        return

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT id, name, price, quantity FROM products")
            records = cursor.fetchall()
            print("\nID | Name       | Price   | Quantity")
            print("-" * 35)
            for row in records:
                print(f"{row[0]:<3} | {row[1]:<10} | {row[2]:<7.2f} | {row[3]:<8}")
    except Error as e:
        print(f"Error fetching data: {e}")
    finally:
        if connection.is_connected():
            connection.close()

if __name__ == '__main__':
    print("\n--- Current Products ---")
    show_all_products()

    try:
        product_id = int(input("\nEnter the Product ID to update: "))
        new_price = float(input("Enter the new price: "))
    except ValueError:
        print("Invalid input! Product ID must be an integer and price must be a number.")
    else:
        update_product_price(product_id, new_price)

        print("\n--- Updated Products ---")
        show_all_products()

